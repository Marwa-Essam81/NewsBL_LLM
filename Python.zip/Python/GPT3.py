import QueryCandidateAnalysis
import time
import json
import unicodedata
import pymysql

import openai


# in the following method, we ask the model to get the main subject matter and the subtopics of the query articles.
def getQueryMainSubjectAndSubtopics(queriesfile, inputdir,outputdir):
    qids = QueryCandidateAnalysis.getQueriesId(queriesfile)
    index=0
    for qid in qids.keys():
        print("processing",qid)
        foutput = open(outputdir + "/" + qid + ".txt", "w")
        content = QueryCandidateAnalysis.loadFileContent(inputdir + "/" + qid + ".txt")
        messages = []
        messages.append({"role": "user", "content": "I will give you a news article identified by the tag [Article]. What is the main subject matter of the article?. List also the title of 3 subtopics that the article discusses. Provide your answer in JSON with the following fileds: Main_subject , Subtopics_List. DO NOT explain or say any more words."})
        messages.append({"role": "user", "content": "[Article] "+content})
        notDone = True
        reply = ""
        while (notDone):
            try:
                #print(messages)
                reply = QueryCandidateAnalysis.processChatGPT(messages,True)
                foutput.write(reply)
                foutput.close()
                notDone=False
            except Exception as e:
                print(e)
                if (str(e).__contains__("TPM")):
                    print("sleeping for a per minute request exception")
                    time.sleep(30)
                if (str(e).__contains__("RPM")):
                    print("sleeping for a per minute request exception")
                    time.sleep(30)
                elif (str(e).__contains__("day") or str(e).__contains__("RPD")):
                    print("sleeping a for a day exception")
                    time.sleep(500)
                elif (str(e).__contains__("tokens")):
                    print("Can't process query", qid, ". input requires truncation.")
                    foutput.write(e)
                    notDone = False
                else:
                    QueryCandidateAnalysis.switchkey()


def getQuerySubjects(qfile):
    finput = open(qfile, encoding='utf-8')
    content = ""
    for line in finput.readlines():
        content=content+line+" "
    content=content.replace("```json","").replace("```","")
    data=json.loads(content)
    output=data["Main_subject"]+", "

    for s in range(0,len(data["Subtopics_List"])-1):
        output=output+data["Subtopics_List"][s]+", "
    output = output + data["Subtopics_List"][len(data["Subtopics_List"])-1] + "."
    return output

def getQuerySubjects_Dash(qfile):
    finput = open(qfile, encoding='utf-8')
    content = ""
    for line in finput.readlines():
        content=content+line+" "
    content=content.replace("```json","").replace("```","")
    data=json.loads(content)
    output="- "+data["Main_subject"]+" - "

    for s in range(0,len(data["Subtopics_List"])-1):
        output=output+data["Subtopics_List"][s]+" - "
    output = output + data["Subtopics_List"][len(data["Subtopics_List"])-1] + "."
    return output

def getQuerySubjects_RemoveComma(qfile):
    finput = open(qfile, encoding='utf-8')
    content = ""
    for line in finput.readlines():
        content = content + line + " "
    content = content.replace("```json", "").replace("```", "")
    data = json.loads(content)
    output = data["Main_subject"].replace(",","") + ", "

    for s in range(0, len(data["Subtopics_List"]) - 1):
        output = output + data["Subtopics_List"][s].replace(",","") + ", "
    output = output + data["Subtopics_List"][len(data["Subtopics_List"]) - 1].replace(",","") + "."
    return output

def getQueryMainTopicAndSubjects(qfile):
    finput = open(qfile, encoding='utf-8')
    content = ""
    for line in finput.readlines():
        content=content+line+" "
    content=content.replace("```json","").replace("```","")
    data=json.loads(content)
    outputMain=data["Main_subject"]
    output=""
    for s in range(0,len(data["Subtopics_List"])-1):
        output=output+data["Subtopics_List"][s]+", "
    output = output + data["Subtopics_List"][len(data["Subtopics_List"])-1] + "."
    return outputMain,output


# in the following method we ask the model to provide a summary of the candidate that is related to the given query subject matter and subtopics
# in this prompt, we force the model to provide the output in JSON to avoid any unnecessary explanations for the answer provided.
def outputCandidateSummaryGivenQuerySubject(queriesfile, baselinefile, inputdir, outputDir,rankDepth=5):
    qids = QueryCandidateAnalysis.getQueriesId(queriesfile)
    queriesDocs = QueryCandidateAnalysis.loadBackgroundArticles(baselinefile,rankDepth)
    queriyids = []
    for qid in qids.keys():
        queriyids.append(qid)
    index = 0
    found=False
    while index < len(queriyids):
        qid = queriyids[index]
        print("processing query", qid)
        foutput = open(outputDir+"/"+qid, "w")
        qcandidates = queriesDocs.get(qid)
        qContent= getQuerySubjects(inputdir+"/"+qid+".txt")
        for cindex in range(0, len(qcandidates)):
            notDone = True
            reply = ""
            truncate_At=-1
            while (notDone):
                messages = []
                userInstructMsg= "A reader is seeking information related to the following related subjects: "
                messages.append({"role": "user",
                                 "content": userInstructMsg+qContent})
                userInstructMsg="\n Provide an extractive summary of the article below, identified by the tag [Article], showing what may benefit the reader. Do not exceed 150 words in your answer. Provide your answer in JSON with the field extracted_summary. \n"
                messages.append({"role": "user",
                                 "content": userInstructMsg})
                if(truncate_At>0):
                    dContent = QueryCandidateAnalysis.TruncatetoLastMeaningfulSent(QueryCandidateAnalysis.getDocumentTextFromDataBase(qcandidates[cindex]), truncate_At)
                else:
                    dContent =QueryCandidateAnalysis.getDocumentTextFromDataBase(qcandidates[cindex])
                try:
                    dContent = unicodedata.normalize("NFKD", dContent)
                    messages.append({"role": "user",
                                     "content": "[Article] " + dContent})
                    reply = str(QueryCandidateAnalysis.processChatGPT(messages, True))
                    foutput.write(qcandidates[cindex]+" [Answer] "+reply.replace("\n"," ").strip()+"\n")#.removeprefix("```json").removesuffix("```")
                    notDone = False
                except Exception as e:
                    print(e)
                    if (str(e).__contains__("TPM")):
                        print("sleeping for a per minute request exception")
                        time.sleep(30)
                    if (str(e).__contains__("RPM")):
                        print("sleeping for a per minute request exception")
                        time.sleep(30)
                    elif (str(e).__contains__("day") or str(e).__contains__("RPD") ):
                        print("sleeping a for a day exception")
                        time.sleep(500)
                    elif (str(e).__contains__("tokens")):
                        print("candidate require truncation.")
                        truncate_At=10000
                    else:
                        QueryCandidateAnalysis.switchkey()
        foutput.close()
        index = index + 1


def getPassagesOfCandidates(qfile):
    passagesSent=""
    count=1
    with open(qfile, encoding='utf-8') as f:
        for line in f:
            try:
                data=line.split("[Answer]")
                #print(data[1])
                passageTxt=json.loads(data[1].strip().replace("```json","").replace("```","").replace(", }"," }"))["extracted_summary"]
                passagesSent=passagesSent+"[Passage "+str(count)+"] "+ passageTxt+"\n"
                count=count+1
            except Exception as e:
                print(e)
                print(line)
    if(count!=16):
        print("only ",count,"passages were found for query",qfile)
    return passagesSent

def getPassagesListOfCandidates(qfile):
    passageList=[]
    count=1
    with open(qfile, encoding='utf-8') as f:
        for line in f:
            data=line.split("[Answer]")
            passageTxt=json.loads(data[1].strip().replace("```json","").replace("```",""))["extracted_summary"]
            passageList.append(passageTxt)
            count=count+1
    if(count!=16):
        print("only ",count,"passages were found for query",qfile)
    return passageList


def RerankCandidatePassagesGivenMainTopicAndSubjects_Forward(queriesfile, queriesdir,candidatesDir, outputDir):
    qids = QueryCandidateAnalysis.getQueriesId(queriesfile)
    queriyids = []
    for qid in qids.keys():
        queriyids.append(qid)
    index = 0
    found=False
    while index < len(queriyids):
        qid = queriyids[index]
        qmain,qsubtopics = getQueryMainTopicAndSubjects(queriesdir+"/"+qid+".txt")
        print("processing query", qid)
        foutput = open(outputDir+"/"+qid, "w")

        notDone = True
        reply = ""
        while (notDone):
            try:
                messages = []
                messageOutput=""
                userInstructMsg = "A news reader is seeking background and context information related to the main topic: "+qmain+" , with details on ANY of the following subtopics: "+qsubtopics+"\n"
                messageOutput=userInstructMsg
                messages.append({"role": "user",
                                 "content": userInstructMsg})
                userInstructMsg=getPassagesOfCandidates(candidatesDir+"/"+qid)
                messages.append({"role": "user",
                                 "content": "Rank the passages below from [Passage 1] to [Passage 15] given how much they provide useful information to the reader. Provide your answer in JSON with the field ranked_list. DO NOT justify your ranking.\n"})
                messageOutput=messageOutput+"Rank the passages below from [Passage 1] to [Passage 15] given how much they provide useful information to the reader. Provide your answer in JSON with the field ranked_list. DO NOT justify your ranking.\n"
                messages.append({"role": "user",
                                 "content": userInstructMsg})
                messageOutput=messageOutput+userInstructMsg
                print(messageOutput)
                reply = str(QueryCandidateAnalysis.processChatGPT(messages, True))
                foutput.write(reply.strip())#.removeprefix("```json").removesuffix("```"))
                notDone = False
            except Exception as e:
                print(e)
                if (str(e).__contains__("TPM")):
                    print("sleeping for a per minute request exception")
                    time.sleep(30)
                if (str(e).__contains__("RPM")):
                    print("sleeping for a per minute request exception")
                    time.sleep(30)
                elif (str(e).__contains__("day") or str(e).__contains__("RPD") ):
                    print("sleeping a for a day exception")
                    time.sleep(500)
                elif (str(e).__contains__("tokens")):
                    print("Can't process query",qid ,". candidates require truncation.")
                    foutput.write(e)
                    notDone = False
                else:
                    # print(e)
                    # print("timeout--again")
                    QueryCandidateAnalysis.switchkey()
        foutput.close()
        index = index + 1


def RerankCandidatePassagesGivenSubjects_Forward(queriesfile, queriesdir,candidatesDir, outputDir):
    qids = QueryCandidateAnalysis.getQueriesId(queriesfile)
    queriyids = []
    for qid in qids.keys():
        queriyids.append(qid)
    index = 0
    found=False
    while index < len(queriyids):
        qid = queriyids[index]
        qContent = getQuerySubjects(queriesdir+"/"+qid+".txt")
        print("processing query", qid)
        foutput = open(outputDir+"/"+qid, "w")
        notDone = True
        reply = ""
        while (notDone):
            try:
                messages = []
                userInstructMsg = "A reader is seeking background and context information related to the following related subjects: " + qContent+"\n"
                messages.append({"role": "user",
                                 "content": userInstructMsg})
                userInstructMsg=getPassagesOfCandidates(candidatesDir+"/"+qid)

                messages.append({"role": "user",
                                 "content": "Rank the passages below from [Passage 1] to [Passage 15] given how much they provide useful information to the reader. Provide your answer in JSON with the field ranked_list. DO NOT justify your ranking.\n"})
                messages.append({"role": "user",
                                 "content": userInstructMsg})
                print(messages)
                reply = str(QueryCandidateAnalysis.processChatGPT(messages, True))
                foutput.write(reply.strip())#.removeprefix("```json").removesuffix("```"))
                notDone = False
            except Exception as e:
                print(e)
                if (str(e).__contains__("TPM")):
                    print("sleeping for a per minute request exception")
                    time.sleep(30)
                if (str(e).__contains__("RPM")):
                    print("sleeping for a per minute request exception")
                    time.sleep(30)
                elif (str(e).__contains__("day") or str(e).__contains__("RPD") ):
                    print("sleeping a for a day exception")
                    time.sleep(500)
                elif (str(e).__contains__("tokens")):
                    print("Can't process query",qid ,". candidates require truncation.")
                    foutput.write(e)
                    notDone = False
                else:
                    # print(e)
                    # print("timeout--again")
                    QueryCandidateAnalysis.switchkey()
        foutput.close()
        index = index + 1



def outputRunFromGPTRerankedPassagesForward(queriesfile, candidatesRelDir, candidatesRankDir,outputfile,depth):
    foutput = open(outputfile, "w")
    qbaselinedocs={}
    qids = QueryCandidateAnalysis.getQueriesId(queriesfile)
    for qid in qids.keys():
        print("processing query",qid)
        baselineDocs=[]
        with open(candidatesRelDir+"/"+qid, encoding='utf-8') as f:
            for line in f:
                data = line.split("[Answer]")
                if(data[0].strip()!=""):
                    baselineDocs.append(data[0].strip())
        if(len(baselineDocs)<depth):
            print("error in query",qid)
        with open(candidatesRankDir+"/"+qid, encoding='utf-8') as f:
            content=""
            for line in f:
                content=content+line.strip()+" "
            #print(content)
            if(content.__contains__("```json")):
                content=content.replace("```json","")
                content=content[0:content.index("```")].strip()
            #print(content)
            #if(content.__contains__("\"Passage")!=True):
            #    content=content.replace("[","[\"").replace("]","\"]").replace(",","\",\"")
            #    print(content)
            Ranking=json.loads(content)["ranked_list"]
            #print(Ranking)
            score=15
            for p in Ranking:
                passageNo=str(p).strip().split(" ")[1].replace("\"","")
                #print(p,passageNo)
                candidate = int(passageNo) - 1
                foutput.write(qid + " Q0 " + baselineDocs[candidate] + " 0 " + str(score) + " QU_KTR\n")
                score=score-1
        #c=input("do you want to continue?")
        #if(c=="0"):
        #    break
    foutput.close()
    print("done")


def getCandidateRankingFromForwardPass(queryfile):
    candidateScore={}
    with open(queryfile, encoding='utf-8') as f:
        content = ""
        for line in f:
            content = content + line.strip() + " "
        # print(content)
        if(content.__contains__("```json")):
            content = content.replace("```json", "")
            content = content[0:content.index("```")].strip()
        # print(content)
        # if(content.__contains__("\"Passage")!=True):
        #    content=content.replace("[","[\"").replace("]","\"]").replace(",","\",\"")
        #    print(content)
        Ranking = json.loads(content)["ranked_list"]
        # print(Ranking)
        score = 15
        for p in Ranking:
            passageNo = str(p).strip().split(" ")[1].replace("\"", "")
            # print(p,passageNo)
            candidate = int(passageNo)-1
            candidateScore[candidate]=score
            score = score - 1
    return candidateScore



def sortMapGivenBaselineOrder(ScoresMap):
    OutputArray=[]
    while(len(ScoresMap.keys()) != 0):
        maxValue=max(ScoresMap.values())
        #print(maxValue)
        tempMap={}
        KeysWithMax={}
        for key in ScoresMap.keys():
            if ScoresMap[key]==maxValue:
                KeysWithMax[key]=ScoresMap[key]
            else:
                tempMap[key]=ScoresMap[key]
        # Now sort the keysWithMax
        sorted_dict = dict(sorted(KeysWithMax.items()))
        for key in sorted_dict.keys():
            OutputArray.append(key)
        ScoresMap=tempMap
    #print(OutputArray)
    return OutputArray



def outputRunFromGPTRerankedPassagesForward_With_Baseline(queriesfile, candidatesRelDir, candidatesFRankDir,candidatesBRankDir,outputfile,depth):
    foutput = open(outputfile, "w")
    qbaselinedocs={}
    qids = QueryCandidateAnalysis.getQueriesId(queriesfile)
    for qid in qids.keys():
        print("processing query",qid)
        baselineDocs=[]
        with open(candidatesRelDir+"/"+qid, encoding='utf-8') as f:
            for line in f:
                data = line.split("[Answer]")
                if(data[0].strip()!=""):
                    baselineDocs.append(data[0].strip())
        if(len(baselineDocs)<depth):
            print("error in query",qid)
        candidateFScores=getCandidateRankingFromForwardPass(candidatesFRankDir+"/"+qid)
        #print(candidateFScores)
        #candidateBScores=getCandidateRankingFromBackwardPass(candidatesBRankDir+"/"+qid)
        #print(candidateBScores)
        candidateTScores={}
        for key in candidateFScores.keys():
            candidateTScores[key]=candidateFScores[key]+(15-key) # We add here the inverse baseline rank, the top document retrieved in the baseline whose index is 0 is given the score 15 and so on
        sorted_candidateScores=sortMapGivenBaselineOrder(candidateTScores)
        for i in range(0,15):
            foutput.write(qid + " Q0 " + baselineDocs[sorted_candidateScores[i]] + " 0 " + str(15-i) + " QU_KTR\n")
        #c=input("do you want to continue?")
        #if(c=="0"):
        #    break
    foutput.close()
    print("done")




if __name__ == '__main__':

	# To run the proposed reranking approach for the 2019 query articles set for example, you will need the provided file: (Queries2019.txt) that includes information of the queries. You will also need a directory that includes a text file for each query content. This directory is not provided for copyright issues. You can create it however from the database you made of the dataset using the method QueryCandidateAnalysis.getDocumentTextFromDataBase and the queries document ides that you can extract from the Queries2019.txt file.

    # Analysis based Approach

	#Step 1 : getQueryMainSubjectAndSubtopics
    #Step 2:  outputCandidateSummaryGivenQuerySubject
    #Step 3: RerankCandidatePassagesGivenSubjects_Forward
    #Step 4: Obtain the run : outputRunFromGPTRerankedPassagesForward
    #Step 5: outputRunFromGPTRerankedPassagesForward_With_Baseline

    ##############################################
	# Examples of running the proposed approach on the queries of 2019
	###########################
    '''
		getQueryMainSubjectAndSubtopics("Queries2019.txt","QueriesTxt2019","Queries")
    	outputCandidateSummaryGivenQuerySubject("Queries2019.txt", "Baseline_2019_1000V4.txt","Queries","Candidates",15)
    	RerankCandidatePassagesGivenSubjects_Forward("Queries2019.txt", "Queries","Candidates", "Ranking")
		outputRunFromGPTRerankedPassagesForward("Queries2010.txt", "Candidates", "_GPT4/MainSubjectSubtopics/Ranking", "2019F_Run_GPT3.txt", 15)
       outputRunFromGPTRerankedPassagesForward_With_Baseline("Queries2019.txt", "Candidates", "Ranking","", "2019F_BaselineRun_GPT3.txt", 15)
   	'''