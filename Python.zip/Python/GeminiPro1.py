import unicodedata

import QueryCandidateAnalysis

from google.generativeai import ChatSession
import QueryCandidateAnalysis
key="" #insert key here
import google.generativeai as genai

genai.configure(api_key=key)


def getQueriesId(queriesfile):
    toggle = True
    queriesIds = {}
    with open(queriesfile, encoding='utf-8') as f:
        for line in f:
            if toggle:
                data = line.split(",")
                queriesIds[data[1]] = data[0]
                toggle = False
            else:
                toggle = True
    return queriesIds



def getQueryMainSubjectAndSubtopics(queriesfile, inputdir,outputdir):

    blockedQueries=[]
    model=createGeminiModel()
    qids = getQueriesId(queriesfile)
    index=0
    found=False
    for qid in qids.keys():
        chat = model.start_chat(history=[])
        '''if(found==False):
            if(qid=="839"):
                found=True
            else:
                continue'''
        #articles=["839"]#"873","839"
        #if (articles.__contains__(qid) != True):
        #    continue
        print("processing",qid)
        content = QueryCandidateAnalysis.loadFileContent(inputdir + "/" + qid + ".txt")
        content = unicodedata.normalize("NFKD", content)
        #print(content)
        messages = "I will give you a news article identified by the tag [Article]. What is the main subject matter of the article?. List also the title of 3 subtopics that the article discusses. Provide your answer in JSON with the following fileds: Main_subject , Subtopics_List. DO NOT explain or say any more words." #The news article may contain words about sex,hate,danger or harrasment.
        messages=messages+"\n"+" [Article] "+content
        notDone = True
        reply = ""
        while (notDone):
            try:
                foutput = open(outputdir + "/" + qid + ".txt", "w")
                #print(messages)
                reply = processGeminiProChat(messages,model,chat)
                #print(reply.text)
                #reply = processGeminiProChat("[Article] "+content, model,chat)
                #print(reply.text)
                foutput.write(reply.text)
                foutput.close()
                notDone=False

            except Exception as e:
                blockedQueries.append(qid+","+str(e))
                foutput.close()
                notDone = False
                #print(e)
                #print(reply.parts)
                #exit()
        index=index+1
        #if(index==1):
        #    break
    print(blockedQueries)

modelName="gemini-pro"
def createGeminiModel():
    generation_config = {
        "candidate_count": 1,
        "temperature": 0,
        "top_p": 1,
        "top_k": 1,
        "max_output_tokens": 3000,# 1000,
    }
    safety_settings = [
        {
            "category": "HARM_CATEGORY_HARASSMENT",
            "threshold": "BLOCK_NONE"
        },
        {
            "category": "HARM_CATEGORY_HATE_SPEECH",
            "threshold": "BLOCK_NONE"
        },
        {
            "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
            "threshold": "BLOCK_NONE"
        },
        {
            "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
            "threshold": "BLOCK_NONE"
        },
    ]
    model = genai.GenerativeModel(model_name=modelName,
                                  generation_config=generation_config,
                                  safety_settings=safety_settings)
    return model

def processGeminiPro(message,model):
    prompt_parts = [
        message]
    response = model.generate_content(prompt_parts)
    #print(.
    return response


def processGeminiProChat(message,model,chat):
    response = chat.send_message(message)
    return response



import json
def getQuerySubjects(qfile):
    finput = open(qfile, encoding='utf-8')
    content = ""
    for line in finput.readlines():
        content=content+line+" "
    if(content.__contains__("```json")):
            content=content.replace("```json","").replace("```","")
    if (content.__contains__("```")):
            content=content.replace("```", "")
    data=json.loads(content)
    output=data["Main_subject"]+", "
    for s in range(0,len(data["Subtopics_List"])-1):
        output=output+data["Subtopics_List"][s]+", "
    output = output + data["Subtopics_List"][len(data["Subtopics_List"])-1] + "."
    return output

def outputCandidateSummaryGivenQuerySubject(queriesfile, baselinefile, inputdir, outputDir,rankDepth=5):
    blockedQueries=[]
    model = createGeminiModel()
    qids = getQueriesId(queriesfile)
    queriesDocs = QueryCandidateAnalysis.loadBackgroundArticles(baselinefile,rankDepth)
    queriyids = []
    for qid in qids.keys():
        queriyids.append(qid)
    index = 0
    found=False
    while index < len(queriyids):
        qid = queriyids[index]
        print("processing query", qid)
        foutput = open(outputDir+"/"+qid, "w")
        qcandidates = queriesDocs.get(qid)
        qContent=""
        try:
            qContent= getQuerySubjects(inputdir+"/"+qid+".txt")
        except:
            blockedQueries.append(qid + ", error in getting subjects for query")
            index=index+1
            foutput.close()
            continue
        for cindex in range(0, len(qcandidates)):
            print("processing candidate",cindex)
            notDone = True
            reply = ""
            truncate_At=-1
            while (notDone):
                messages = ""
                chat = model.start_chat(history=[])
                userInstructMsg= "A reader is seeking information related to the following related subjects: "
                messages= messages+ userInstructMsg+qContent
                userInstructMsg="\n Provide an extractive summary of the article below, identified by the tag [Article], showing what may benefit the reader. Do not exceed 150 words in your answer. Provide your answer in JSON with the field extracted_summary. \n"
                messages= messages+" "+userInstructMsg
                if(truncate_At>0):
                    dContent = QueryCandidateAnalysis.TruncatetoLastMeaningfulSent(
                    QueryCandidateAnalysis.getDocumentTextFromDataBase(qcandidates[cindex]), truncate_At)
                else:
                    dContent =QueryCandidateAnalysis.getDocumentTextFromDataBase(qcandidates[cindex])
                try:
                    dContent = unicodedata.normalize("NFKD", dContent)
                    messages = messages + "[Article] " + dContent
                    reply=processGeminiProChat(messages,model,chat)
                    reply = reply.text
                    foutput.write(qcandidates[cindex]+" [Answer] "+reply.replace("\n"," ").strip()+"\n")#.removeprefix("```json").removesuffix("```")
                    notDone = False
                except Exception as e:
                    print(e)
                    blockedQueries.append(qid + "," +qcandidates[cindex]+"," +str(e))
                    foutput.write(qcandidates[cindex]+" [Answer] "+"\n")#.removeprefix("```json").removesuffix("```")
                    notDone = False

        foutput.close()
        index = index + 1
    print(blockedQueries)

def getTitleAndFirstPara(docfile):
    docTxt=""
    finput = open(docfile, encoding='utf-8')
    content = ""
    for line in finput.readlines():  # Truncating long files to a number of words.
        content = content + line + " "
    paras = content.strip().split("<Paragraph>")
    for p in range(0,3):
        docTxt = docTxt + paras[p] + " "
    return docTxt

def getPassagesOfCandidates(qfile):
    passagesSent=""
    count=1
    with open(qfile, encoding='utf-8') as f:
        for line in f:
            try:
                data=line.split("[Answer]")
                Summary=data[1]
                if (Summary.__contains__("\"summary\"")):
                    Summary=Summary.replace("\"summary\"","\"extracted_summary\"")
                elif (Summary.__contains__("\"extractive_summary\"")):
                    Summary=Summary.replace("\"extractive_summary\"","\"extracted_summary\"")

                if(Summary.__contains__("```json")):
                    passageTxt=json.loads(Summary.strip().replace("```json","").replace("```","").replace(", }"," }"))["extracted_summary"]
                else:
                    passageTxt = json.loads(Summary.strip())["extracted_summary"]
                passagesSent=passagesSent+"[Passage "+str(count)+"] "+ passageTxt+"\n"
                count=count+1
            except Exception as e:
                print(e)
                print(line)
    if(count!=16):
        print("only ",count,"passages were found for query",qfile)
    return passagesSent

def RerankCandidatePassagesGivenSubjects_Forward(queriesfile, queriesdir,candidatesDir, outputDir):
    qids = getQueriesId(queriesfile)
    queriyids = []
    for qid in qids.keys():
        queriyids.append(qid)
    index = 0
    found=False
    model = createGeminiModel()
    while index < len(queriyids):
        qid = queriyids[index]

        chat = model.start_chat(history=[])
        toCorrect=["928","902","917","926","904"]
        if(toCorrect.__contains__(qid)!=True):
            #print("done with query", qid)
            index=index+1
            continue
        print("processing query", qid)
        qContent = getQuerySubjects(queriesdir+"/"+qid+".txt")
        foutput = open(outputDir+"/"+qid, "w")
        notDone = True
        reply = ""
        while (notDone):
            try:
                messages = ""
                userInstructMsg = "A reader is seeking background and context i1nformation related to the following related subjects: " + qContent+"\n "
                messages=messages+userInstructMsg
                userInstructMsg=getPassagesOfCandidates(candidatesDir+"/"+qid)
                contentOrder="Rank the passages below from [Passage 1] to [Passage 15] given how much they provide useful information to the reader. Provide your answer in JSON with the field ranked_list. DO NOT justify your ranking.\n "
                messages = messages + contentOrder+userInstructMsg
                print(messages)
                reply = processGeminiProChat(messages, model, chat)
                reply = reply.text
                foutput.write(reply.strip())#.removeprefix("```json").removesuffix("```"))
                notDone = False
                foutput.close()
            except Exception as e:
                print(e)
                print(reply)
                #print(reply.candidates[0].content.parts)
                print("can't process query",qid)
                notDone = False
                foutput.close()
        index = index + 1

def sortMapGivenBaselineOrder(ScoresMap):
    OutputArray=[]
    while(len(ScoresMap.keys()) != 0):
        maxValue=max(ScoresMap.values())
        #print(maxValue)
        tempMap={}
        KeysWithMax={}
        for key in ScoresMap.keys():
            if ScoresMap[key]==maxValue:
                KeysWithMax[key]=ScoresMap[key]
            else:
                tempMap[key]=ScoresMap[key]
        # Now sort the keysWithMax
        sorted_dict = dict(sorted(KeysWithMax.items()))
        for key in sorted_dict.keys():
            OutputArray.append(key)
        ScoresMap=tempMap
    #print(OutputArray)
    return OutputArray

def getCandidateRankingFromForwardPass(queryfile):
    candidateScore={}
    with open(queryfile, encoding='utf-8') as f:
        content = ""
        for line in f:
            content = content + line.strip() + " "
        # print(content)
        if(content.__contains__("```json")):
            content = content.replace("```json", "")
            content = content[0:content.index("```")].strip()
        # print(content)
        # if(content.__contains__("\"Passage")!=True):
        #    content=content.replace("[","[\"").replace("]","\"]").replace(",","\",\"")
        #    print(content)
        Ranking = json.loads(content)["ranked_list"]
        # print(Ranking)
        score = 15
        for p in Ranking:
            passageNo = str(p).strip().split(" ")[1].replace("\"", "")
            # print(p,passageNo)
            candidate = int(passageNo)-1
            candidateScore[candidate]=score
            score = score - 1
        ### The following code is to add missing passages at the tail of the ranked_list
        missed=0
        while(len(candidateScore)<15):
            if(candidateScore.keys().__contains__(missed)!=True):
                candidateScore[missed]=score
                score=score-1
            missed=missed+1

    return candidateScore

def outputRunFromGPTRerankedPassagesForward_With_Baseline(queriesfile, candidatesRelDir, candidatesFRankDir,candidatesBRankDir,outputfile,depth):
    foutput = open(outputfile, "w")
    qbaselinedocs={}
    qids = getQueriesId(queriesfile)
    for qid in qids.keys():
        print("processing query",qid)
        try:
            baselineDocs=[]
            with open(candidatesRelDir+"/"+qid, encoding='utf-8') as f:
                for line in f:
                    data = line.split("[Answer]")
                    if(data[0].strip()!=""):
                        baselineDocs.append(data[0].strip())
            if(len(baselineDocs)<depth):
                print("error in query",qid)
            candidateFScores=getCandidateRankingFromForwardPass(candidatesFRankDir+"/"+qid,15)

            candidateTScores={}
            for key in candidateFScores.keys():
                candidateTScores[key]=candidateFScores[key]+(15-key) # We add here the inverse baseline rank, the top document retrieved in the baseline whose index is 0 is given the score 15 and so on
            sorted_candidateScores=sortMapGivenBaselineOrder(candidateTScores)
            for i in range(0,15):
                foutput.write(qid + " Q0 " + baselineDocs[sorted_candidateScores[i]] + " 0 " + str(15-i) + " QU_KTR\n")
        except Exception as e:
            print(e)
    foutput.close()
    print("done")

import shutil

def OutputCandidateBKFilesForLLM(baselinefile,srcDir,rankingdepth=15):
    queriesDocs = {}
    with open(baselinefile, encoding='utf-8') as f:
        for line in f.readlines():
            data = line.split(" ")
            if (queriesDocs.__contains__(data[0]) != True):
                queriesDocs[data[0]] = []
            if(len(queriesDocs[data[0]])<rankingdepth):
                queriesDocs[data[0]].append(data[2])
                print(data[2])
                shutil.copyfile(srcDir+"/"+data[2], '15CandidateBKDocs/'+data[2])
    for key in queriesDocs.keys():
        if(len(queriesDocs[key])<rankingdepth):
            print("couldn't find enough candidates for query",key)
    print("done",srcDir)

if __name__ == '__main__':
    '''
    getQueryMainSubjectAndSubtopics("Queries2019.txt","QueriesTxt2019","Pro1/Queries/2019")
    outputCandidateSummaryGivenQuerySubject("Queries2019.txt", "Baseline_2019_1000V4.txt",
                                            "Pro1/Queries/2019",
                                            "Pro1/Candidates/2019", 15)

    RerankCandidatePassagesGivenSubjects_Forward("Queries2019.txt","output/Queries/2019","Pro1/Candidates/2019","Pro1/Ranking/2019")

    outputRunFromGPTRerankedPassagesForward_With_Baseline("Queries2019.txt", "Pro1/Candidates/2019", "Pro1/CleanedRanking/2019","", "Pro1/GPro1-Analysis-2019-Baseline.txt", 15)
    #print("done 2019")
    '''
