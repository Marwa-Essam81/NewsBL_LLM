import openai

#Add the following lines post downloading a certificate file from openai if your machine has a security problem
# import os
#os.environ['REQUESTS_CA_BUNDLE'] = 'OpenAI.cer'
keyvalue=3
openai.api_key=''
openkeys=['']
def getQueriesId(queriesfile):
    toggle = True
    queriesIds = {}
    with open(queriesfile, encoding='utf-8') as f:
        for line in f:
            if toggle:
                data = line.split(",")
                queriesIds[data[1]] = data[0]
                toggle = False
            else:
                toggle = True
    return queriesIds

def switchkey():
    global keyvalue
    keyvalue=keyvalue+1
    if (keyvalue==len(openkeys)):
        keyvalue=0
    openai.api_key=openkeys[keyvalue]
    return keyvalue

import time
import json
import timeout_decorator

import pymysql
def accessDatabase(statement):
    # print("Executing statement",statement)
    mydb = pymysql.connect(
        host="localhost",
        user="root",
        password="123456789",
        db="WPostDBV4"
    )

    mycursor = mydb.cursor()

    mycursor.execute(statement)

    myresult = mycursor.fetchall()

    return myresult

def getDocumentTextFromDataBase(docid):
    content=""
    statement = "Select title from documents where id like'" +docid + "'"
    result = accessDatabase(statement)
    title = str(result[0][0]).strip()
    content= content+title
    statement = "Select data from contents where did like'" + docid + "' order by pos"
    paragraphs = accessDatabase(statement)
    for para in paragraphs:
        p=str(para[0]).strip()
        content= content+p+" "
    return content

@timeout_decorator.timeout(60,timeout_exception=StopIteration)
def processChatGPT(messages,jsonFlag):
    m1="gpt-3.5-turbo-1106"
    m2="gpt-4-1106-preview"
    if(jsonFlag==True):
        chat = openai.ChatCompletion.create(model=m1, messages=messages, temperature=0.0,format = "json")
    else:
        chat = openai.ChatCompletion.create(model=m2, messages=messages, temperature=0.0,format = "json")
    reply = chat.choices[0].message.content
    return reply

def loadFileContent(filename, returnlimit=-1):
    try:
        finput = open(filename, encoding='utf-8')
        content = ""
        for line in finput.readlines():  # Truncating long files to a number of words.
            content = content + line + " "
        clearContent = ""
        if content.__contains__("<Paragraph>"):
            return ""
        else:
            if (returnlimit == -1):
                return content.strip()
            wordtokens = content.split(" ")
            if (len(wordtokens) > returnlimit):
                content = " "
                for l in range(0, returnlimit):
                    content = content + wordtokens[l] + " "
            # print(filename,len(wordtokens),len(content.split(" ")))
            return content.strip()
    except Exception as e:
        print(e)
        return "NotFound"

#The following method truncates a text to the last sentence that is meaningful and that has a proper end. This method is used when taking a fixed
# number of words from a news article and we want what is taken to be meaningful without an incomplete sentence.
def TruncatetoLastMeaningfulSent(inputStr):
    trimindex=len(inputStr)-1
    trimchars=['.',"?","!"]
    while(True):
        if trimchars.__contains__(inputStr[trimindex]):
            break
        else:
            trimindex=trimindex-1
    return inputStr[0:trimindex+1]

def loadBackgroundArticles(baselinefile,rankingdepth=1000):
    queriesDocs = {}
    with open(baselinefile, encoding='utf-8') as f:
        for line in f.readlines():
            data = line.split(" ")
            if (queriesDocs.__contains__(data[0]) != True):
                queriesDocs[data[0]] = []
            if(len(queriesDocs[data[0]])<rankingdepth):
                queriesDocs[data[0]].append(data[2])
    for key in queriesDocs.keys():
        if(len(queriesDocs[key])<rankingdepth):
            print("couldn't find enough candidates for query",key)
    return queriesDocs

